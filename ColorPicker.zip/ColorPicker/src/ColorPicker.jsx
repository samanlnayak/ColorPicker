import React, { useState } from "react";

function ColorPicker() {
  const [color, setColor] = useState("#FFFFFF");

  function handleColor(event) {
    setColor(event.target.value);
  }

  return (
    <div className="color-picker-container">
      <h1>Color Picker</h1>
      <div className="color-display" style={{ backgroundColor: color }}>
        <p>Selected Color: {color}</p>
      </div>

      <label htmlFor="colorInput">Select a color: </label>
      <input
        id="colorInput"
        type="color"
        value={color}
        onChange={handleColor}
      />
      <h2>Selected Color: {color}</h2>
    </div>
  );
}

export default ColorPicker;
