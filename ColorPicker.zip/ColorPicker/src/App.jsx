import { useState } from 'react'
import ColorPicker from './ColorPicker'

function App() {
  
  return(
    <>
      <ColorPicker/>
    </>
  )
  
}

export default App
